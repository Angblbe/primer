# p-poo-00

### Lab Animals

Per fer a classe amb l'ajuda del professor i companys.


### Lab Vehicles

Per fer individualment, i compte per nota.

> Heu de seguir les instruccions, però enlloc de fer els labs amb VSCode, en aquest curs (22-23) els farem amb Eclipse.
